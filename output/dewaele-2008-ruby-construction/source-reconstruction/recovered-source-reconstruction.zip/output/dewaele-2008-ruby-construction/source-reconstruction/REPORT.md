# Dewaele 2008: reconstruction from recovered numerical sources

## Result and status

The available source isotherms support a reproducible **conditional reconstruction**. They do not reproduce the authors' published A=1920 GPa, B=9.61 exactly under the declared equal-metal averaging and pressure-residual objective. This is not a replacement pressure standard. The original calibration is not disproven.

The principal reconstruction uses recovered room-temperature isotherms, ultrasonic-fixed bulk moduli and the stated fitting ranges. A second source reconstruction uses the full Co handbook table because it reproduces the printed Co derivative much more closely. That range change remains a diagnostic hypothesis. The literal printed Vinet-pair replay is retained separately, including the inconsistent Pt entry.

| Construction | A (GPa) | B | Reconstructed minus published at 160 GPa |
| --- | ---: | ---: | ---: |
| Published 2008 | 1920 | 9.61 | 0 |
| Recovered sources; stated fit ranges | 1916.9302 | 10.152566 | +2.6895 GPa |
| Recovered sources; Co full table | 1915.1381 | 10.056143 | +2.0094 GPa |
| Literal published Vinet pairs | 1911.0264 | 9.792775 | +0.2337 GPa |
| Recovered sources; common DAC range | 1909.9335 | 10.401493 | +3.4650 GPa |

For the common-range fit, values beyond the common DAC domain are extrapolations. All differences compare identical ruby wavelength ratios; the horizontal coordinate is the published 2008 pressure, not an independently known true pressure.

![Calibration reconstruction](calibration-reconstruction.png)

## Numerical construction

1. Preserve the original source tables and published parameters. Fit recovered shock-reduced P versus V/V0 values to Vinet with K0 fixed to the reported ultrasonic value.
2. Use the published fixed-K0 DAC Vinet branches: 2008 Table IV for Co/Ni/Mo/Ag; 2004 Table II for Al/Cu/Pt/Ta/W; stress-corrected 2007 Au. The main Co branch uses K0=184 GPa.
3. At each P04 in 0–160 GPa, invert each DAC EOS to obtain V/V0, then evaluate its reduced-shock EOS at that same volume. Take the arithmetic mean of ten pressures. Zn and Fe are not members of the ten-metal average.
4. Convert P04 to the ruby coordinate using ln(r)=ln(1+9.5*P04/1904)/9.5. Fit P=A/B*expm1(B*ln(r)) to that mean, with A and B free.

All pressure-residual fits are unweighted least squares. Each metal receives equal weight in the final average. Analytic source curves and final ruby fits use 321 uniformly spaced pressure points. These sampling and weighting choices are explicit analyst assumptions; the papers do not specify them sufficiently for an author-workflow replay.

Each reduced isotherm is normalized to its own source reference volume and matched to the DAC V/V0. This adopts a common reference normalization; no absolute shock-derived ambient atomic volume or thermal correction is invented.

## Recovered input use and coefficient comparison

| Metal | Fixed RSW K0 (GPa) | Literal source K0′ | Recovered-source fit K0′ |
| --- | ---: | ---: | ---: |
| Co | 184 | 4.9300 | 5.156620 |
| Ni | 183 | 5.1300 | 5.127963 |
| Mo | 261 | 4.1800 | 4.212474 |
| Ag | 101 | 6.1900 | 6.195363 |
| Al | 73.46 | 4.5200 | 4.520000 |
| Cu | 133 | 5.3300 | 5.331793 |
| Pt | 277 | 4.6600 | 5.455855 |
| Ta | 194 | 3.7600 | 3.769884 |
| W | 296 | 4.4500 | 4.437794 |
| Au | 167 | 5.8200 | 5.803518 |

Source selection:

- **Co/Ni/Ag:** handbook 25 °C (298.15 K) values, with source shock-pressure limits 65.2/156.6/97.9 GPa respectively. This retains 36/44/42 tabulated points. Ni's table ends at 120 GPa. All 136 recovered table values remain preserved; entries outside the selected fit range are not silently included.
- **Mo/W:** the 293 K Hixson–Fritz density tables, fitted to 97.9 and 160 GPa respectively: 10/17 points. The separate 300 K PVT tables are a declared sensitivity check.
- **Cu/Ta/Au:** Wang Eq.8/Table II generalized universal EOS, sampled over 0–160 GPa then refit to ordinary Vinet. Quartic exponent terms and their signs are retained.
- **Pt:** Holmes Eq.11/Table IV, using exact P_T=798.31 GPa and eta=7.2119, then refit with K0=277 GPa. Wang's Pt parameterization is a separate source-identity check.
- **Al:** the expressly adopted preliminary Dorogokupets pair 73.46/4.52. Its original preliminary thermal fit is unavailable, so this is adopted, not independently refitted.

The recovered raw shock-state tables provide provenance but cannot be substituted for room-temperature isotherms without their thermal reductions. Those original reductions were not rerun: intermediate electronic-energy arrays, selected shock rows and some thermal inputs remain missing. For the same reason, temperatures 293, 298.15 and 300 K are explicitly retained rather than silently equated.

## Two resolved diagnostics and remaining non-parity

**Co range:** the source-stated-range fit gives K0′=5.156620, whereas all 44 handbook Co points through 120 GPa give 4.926612, which rounds to the printed 4.93. This is evidence for a possible wider Co fit domain, not proof of the original selection. No continuous cutoff search was performed.

**Pt source inconsistency:** the 2004 table prints 277/4.66, with ref.23 pointing to Wang, while Figure3 labels the curve Holmes. The recovered Holmes curve gives K0′=5.455855 when refitted at fixed K0=277 GPa. Against the independent 2008 Figure2 Pt checkpoints, the literal pair has RMSE 3.297 GPa, versus 0.145 GPa for the recovered-source fit. The printed value is not silently corrected. Close agreement of the literal ten-metal average with the final ruby curve is therefore insufficient to validate its inputs.

![Per-metal comparisons](per-metal-source-comparison.png)

Other small input differences remain, including Mo's recovered-table derivative versus the printed 4.18. Changing arbitrary weights or row masks to force A/B parity has not been attempted.

## Sensitivity and coverage

| Declared change from principal reconstruction | A (GPa) | B | Difference at 160 GPa |
| --- | ---: | ---: | ---: |
| Hixson 300 K tables | 1917.0595 | 10.162623 | +2.7557 GPa |
| Wang Pt source | 1916.8711 | 10.148394 | +2.6616 GPa |
| Co K0=190 GPa branch | 1916.5755 | 10.146229 | +2.6246 GPa |

These cases are not a statistical confidence interval or an exhaustive error budget. No interval for A/B is claimed: source-model errors, shared calibrations and parameter covariances are not supplied.

All-ten DAC support overlaps only through P04=65.2 GPa. Full-range comparisons therefore continue fitted EOS beyond several metals' measured domains, and the Ni source table is continued above 120 GPa. Corrected Au numerical observations remain unavailable; its published corrected parameterization is used.

## Comparison at selected pressures

| Published 2008 pressure | Principal reconstruction minus published | Co full-table alternative minus published | Literal pairs minus published |
| ---: | ---: | ---: | ---: |
| 40 GPa | +0.1488 GPa | +0.0734 GPa | -0.1157 GPa |
| 80 GPa | +0.6792 GPa | +0.4597 GPa | -0.1040 GPa |
| 120 GPa | +1.5392 GPa | +1.1159 GPa | +0.0170 GPa |
| 160 GPa | +2.6895 GPa | +2.0094 GPa | +0.2337 GPa |

## Verification and reproducibility

Vinet inversion and an independent equal-K0 pressure-ratio identity agree within 3.2e-12 GPa. Increasing both analytic and ruby-fit grids from321 to1601 changes the final 0–160 GPa pressure curve by at most 0.000295 GPa.

The published 1920/9.61 equation agrees with independently recovered Figure3 checkpoints to 0.01069 GPa. That graph is a validation target only and never enters the source-based fit.

The published DAC EOS are also evaluated against the recovered observation rows in `DAC-observation-check.csv`; historical uncorrected Au rows are excluded. He-derived Ni pressures retain their flag and do not acquire invented ruby wavelengths.

Run from the repository or extracted numerical bundle root:

```bash
uv run --no-project --with scipy --with matplotlib python scripts/reconstruct_dewaele_2008_from_recovered_sources.py
```

Inputs are checksummed in `verification.json`. Numerical targets, parameters, final curves and per-metal graphical comparisons are exported alongside this report. No catalogue record, source observation, earlier reconstruction or pressure standard was changed.

## Primary sources

- [Dewaele et al. 2008](https://doi.org/10.1103/PhysRevB.78.104102), Sec.IV, TableIV, Figures2–3.
- [Dewaele et al. 2004](https://doi.org/10.1103/PhysRevB.70.094112), TableII, Sec.III.
- Kennedy–Keeler, AIP Handbook, third edition (1972), Sec.4d-2 and Table4d-12, pp.4-96–4-101.
- [Hixson–Fritz 1992](https://doi.org/10.1063/1.351203), TablesIV–VII.
- [Wang et al. 2002](https://doi.org/10.1063/1.1518781), Eq.8/TableII.
- [Holmes et al. 1989](https://doi.org/10.1063/1.344177), Eq.11/TableIV.
- [Dewaele–Loubeyre 2007](https://doi.org/10.1080/08957950701659627), Sec.5.
- [Dorogokupets–Oganov 2007](https://doi.org/10.1103/PhysRevB.75.024115), preliminary Al coefficients, p.024115-4.
