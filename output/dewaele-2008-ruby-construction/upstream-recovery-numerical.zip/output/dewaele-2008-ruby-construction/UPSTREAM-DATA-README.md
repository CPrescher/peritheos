# Additional upstream source data recovered, 23 October 2026

Hixson–Fritz and Holmes were recovered through the user's local Zotero library.
The later user-requested retrieval site also supplied Wang (2002), Dewaele
(2004), and Dewaele–Loubeyre (2007). Their PDFs remain in the local `sources/`
folder; retrieval URLs, identities and hashes are recorded separately.
The user then supplied the 1972 third-edition AIP Handbook in Downloads,
allowing recovery of all 136 populated Co/Ni/Ag cells and their reduction method.
The full evidence report is `docs/literature-reproductions/dewaele-2008-ruby-construction.md`.

| File | Content | Evidence type |
| --- | --- | --- |
| `hixson-1992-tables6-7-pvt.csv` | 410 P–V–T values, Mo/W, 100–1000 K | Published model calculations |
| `hixson-1992-300K-isotherms.csv` | 41-value subset of the preceding file | Published model calculations; not extra observations |
| `hixson-1992-293K-density-isotherms.csv` | 62 density points, 0–300 GPa | Published model calculations |
| `hixson-1992-tables1-2-shock.csv` | 14 shock states | Reported experiment states; pressure/density derived from shock analysis |
| `hixson-1992-reduction-inputs.json` | Main Hugoniot and thermal parameters, assumptions | Source coefficients; not a new fit |
| `holmes-1989-table3-pt-shock.csv` | Seven shock states with 2-sigma intervals | Reported experiment states; correlated quantities |
| `holmes-1989-300K-parameterization.json` | Analytic theoretical Pt isotherm and precise coefficient convention | Published first-principles parameterization |
| `upstream-recovery-verification.json` | Source hashes, row counts, OCR checks and limits | Recovery provenance |
| `wang-2002-table2-generalized-eos.csv` | Five reduced 300 K EOS parameterizations | Published coefficients, quartic exponent |
| `wang-2002-table1-hugoniot-inputs.csv` | Ten piecewise Hugoniot branches and source assignments | Published input coefficients |
| `wang-2002-source-mapping.json` | Exact Eq.7/8 definitions and limitations | Source formulation |
| `dewaele-2004-table2-vinet-branches.csv` | 30 Vinet branches; fixed/free constraints and fit intervals | Published coefficients |
| `dewaele-2004-table2-source-notes.json` | Acoustic column, confidence semantics, Pt reference ambiguity | Source provenance |
| `dewaele-loubeyre-2007-stress-correction.json` | Au/Cu correction equation and fitted coefficients | Published parameterizations; not observation rows |
| `additional-paper-retrieval.json` | Three PDF identities/hashes, retrieval route and failed handbook search | Retrieval provenance |
| `aip-1972-table4d12-co-ni-ag-isotherms.csv` | 44 Co, 44 Ni, 48 Ag points at 25 C | Published calculated shock-reduced isotherms |
| `aip-1972-table4d12-co-ni-ag-cells.csv` | Same columns, retaining 23 blank cells among 159 total | Source-cell preservation |
| `aip-1972-co-ni-ag-source.json` | Book identity, page locations, Gruneisen/Dugdale–MacDonald method, accuracy semantics | Source provenance |
| `aip-1972-co-ni-ag-verification.json` | All 136 populated cells compared with independent PDF text, visual OCR correction | Transcription verification |

References: Hixson & Fritz (1992), DOI [10.1063/1.351203](https://doi.org/10.1063/1.351203), Tables I–VII; Holmes et al. (1989), DOI [10.1063/1.344177](https://doi.org/10.1063/1.344177), Table III and Eq.11/Table IV.

All column units are named explicitly. Hixson's eta is `1-V/V0`, referenced
to the initial 293 K state. The 293 K and 300 K tables must remain distinct.
The density ratios and `1-eta` volume ratios are explicitly derived columns.
No missing uncertainties, ruby wavelengths, calibration weights or source
observations have been invented. Approximate source-model accuracy statements
are not treated as pointwise statistical errors.

This retrieval does not reproduce Dewaele's original calibration fit. Still
needed: the exact Pt source branch and constrained representation;
numerical corrected 2007 Au observations;
preliminary Al reduction details; and the actual ten-metal sampling, averaging,
weighting and optimization specification. Wang's published analytic reductions
and the original 2004 coefficient table are now recovered, as are the handbook
Co/Ni/Ag columns and their method. Original electronic structure arrays,
selected shock measurements and intermediate reduction samples remain unavailable.

The numerical ZIP excludes publisher PDFs, rendered source pages and extracted
article text. Those remain local evidence. This supplement does not assert
rights over third-party publications. The earlier construction ZIP is a frozen
snapshot and does not include this later recovery.

To re-extract using the exact source PDFs recorded in the verification file,
place them as `sources/hixson-1992.pdf` and `sources/holmes-1989.pdf` under
`output/dewaele-2008-ruby-construction/`, then run from the archive/repository root:

```bash
uv run --no-project --with pdfplumber python scripts/recover_dewaele_2008_upstream_tables.py
```

No catalogue data or calibration coefficients were changed. Nothing was
committed, published or sent to the authors.

To regenerate the handbook source exports, run:

```bash
python scripts/recover_dewaele_2008_handbook.py --pdf /path/to/the/supplied/book.pdf
```

The book remains in Downloads and is not copied into this archive. The
handbook source estimates approximately +/-5% pressure accuracy; that estimate
does not supply pointwise error bars or covariance.
