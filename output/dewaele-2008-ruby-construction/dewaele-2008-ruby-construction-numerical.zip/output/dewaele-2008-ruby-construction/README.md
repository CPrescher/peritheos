# Dewaele 2008 ruby construction investigation

This is a partial source reconstruction. The published equation passes an
independent Figure 3 check; the original ten-metal averaging/optimization and
full upstream shock reductions remain unresolved. It is not a pressure standard.

Start with `docs/literature-reproductions/dewaele-2008-ruby-construction.md` in
the numerical archive, or the same path in the Peritheos checkout. The report
contains the dependency diagram, source citations, coefficient comparisons,
access limits and exact remaining evidence.

The archive includes the dedicated script, factual numerical inputs, previous
explicitly conditional graph diagnostics and new output files. It excludes
third-party PDFs and extracted article text. Raw spectrometer readings and
unrecovered shock observations are not synthesized.

After extracting the archive, run from its root:

```bash
uv run --no-project --with scipy --with matplotlib \
  python scripts/reconstruct_dewaele_2008_ruby_construction.py
```

The included graph transcription permits this run without the original PDF.
To independently recover Figure 3 again, add `--with pdfplumber` to the uv
command and `--recover-pdf /path/to/PhysRevB.78.104102.pdf` after the script.
Recovery requires the exact PDF checksum recorded in the report.

`reconstruction.json`, `dependency-map.json`, `source-table4-vinet-pairs.csv`,
`pressure-volume-input-inventory.csv`, `figure3-source.json`,
`evidence-register.json`, `verification.json` and the two comparison figures
are the principal products. Source comparisons are not raw measured shock data.

No material EOSMAT, existing audit script, common ledger or original PV table
was changed. No commit, publication, release or deployment was made.
