# Dewaele (2008): construction of the ten-metal ruby calibration

## Finding and reconstruction boundary

The published construction can be traced as a sequence of **shock reduction →
Vinet representation → comparison at common volume → ten-metal pressure
average → ruby power-law fit**. The numerical averaging rule and several
upstream inputs remain unrecovered. Consequently, this is a **partial source
reconstruction**, not a reproduction of the authors' optimization. It provides
no replacement pressure standard and changes no material or calibration record.

A new independent check removes one ambiguity: the orange curve in Figure 3
agrees with the printed `A=1920 GPa, B=9.61` formula to **0.0107 GPa maximum**
over 190 recovered vector checkpoints. Thus the published equation and plotted
output are mutually consistent. The earlier extrapolated Figure 2 average is a
different, conditional construction; its disagreement does not establish a typo.

Primary authority is [Dewaele et al. (2008), PRB 78,
104102](https://doi.org/10.1103/PhysRevB.78.104102), especially Section IV,
Tables I–IV and Figures 2–3. The supplied publisher PDF has SHA-256
`a06fd5cb9433b99f35b20582be5214b1e805014c150a2907fdf8933776cf6daf`.
All volumes below are **Å³/atom**, pressures and moduli are **GPa**, and
pressure derivatives are dimensionless. The DAC isotherm is at ambient
temperature; no static-lattice thermal-pressure subtraction belongs in this
ruby calibration calculation.

## Dependency map

```mermaid
flowchart TD
    VELOCITY[Shock and particle velocities plus initial density] --> RH[Rankine–Hugoniot pressure, volume and energy]
    RH --> KK[Kennedy–Keeler compiled reduced isotherms: Co Ni Ag]
    RH --> HF[Hixson–Fritz thermodynamic reductions: Mo W]
    RH --> MFP[Wang mean-field thermal-volume correction: Cu Ta Au]
    RH --> PT[Holmes Pt reduction]
    RH --> AL[SWDB plus zero-pressure thermochemistry and elasticity: preliminary Al]
    US[Ultrasonic isothermal bulk moduli] --> RSW[Vinet representations of reduced shock isotherms]
    KK --> RSW
    HF --> RSW
    MFP --> RSW
    PT --> RSW
    AL --> RSW
    XRD[Measured metal lattice spacings or atomic volumes] --> DAC[Fixed-V0 DAC Vinet fits and ultrasonic-K0 alternatives]
    MAO[Mao 1986 ruby coordinate] --> R04[2004 ruby: A 1904 B 9.5]
    OLD[2004 six-metal shock comparison] --> R04
    R04 --> DAC
    HE[1998 He EOS and unprinted simultaneous He volumes] --> NI[Ni run-6 high-pressure states]
    NI --> DAC
    US --> DAC
    AU[2007 stress-corrected Au diffraction analysis] --> DAC
    DAC --> SAME[Evaluate DAC and RSW pressures at the same volume]
    RSW --> SAME
    SAME --> AVG[Average over ten metals: support and weights unreported]
    AVG --> FIT[Fit pressure against ruby wavelength ratio]
    FIT --> R08[2008 ruby: A 1920 B 9.61]
    R04 --> COORD[Invert input ruby equation to obtain wavelength coordinate]
    COORD --> FIT
```

The upstream reductions share compilations, techniques and sometimes elastic
constraints. The ten elements are not ten demonstrably independent absolute
pressure realizations. The paper's argument that averaging reduces error is
explicitly conditional on unbiased, mutually independent errors (p. 104102-6).

## What entered the calculation, metal by metal

| Metal | Static input used or cited in 2008 | Reduced-shock input | Recovery status |
| --- | --- | --- | --- |
| Co, hcp | 2008 Table II, runs 4–5; fixed `V0=11.096`; Table IV alternatives `K0=184` or `190` | Kennedy–Keeler (1972), ref. 42 | Both DAC/RSW Vinet coefficient pairs are directly recovered; original handbook isotherm rows and shock selection are not |
| Ni, fcc | Table II, runs 4–6; `V0=10.942`, `K0=183`; high-pressure run-6 points include a He gauge | Kennedy–Keeler, ref. 42 | Coefficient pair recovered; raw He volumes and ruby spectra absent from the supplied article |
| Mo, bcc | Table II, runs 1–2; exclude run-2 points above 100 GPa; `V0=15.558`, `K0=261` | [Hixson & Fritz (1992)](https://doi.org/10.1063/1.351203), ref. 43 | 2008 Vinet pair recovered; original numerical isotherms and reduction inputs inaccessible in this run |
| Ag, fcc | Table II, runs 1–3, same run-2 exclusion; `V0=17.021`, `K0=101` | Kennedy–Keeler, ref. 42 | 2008 pair recovered; original handbook isotherm rows not recovered |
| Al, fcc | [2004 six-metal study](https://doi.org/10.1103/PhysRevB.70.094112), Table I and II | [Dorogokupets & Oganov (2007)](https://doi.org/10.1103/PhysRevB.75.024115), **initial** `73.46,4.52` model | Exact adopted coefficients and fitting-stage distinction verified; preliminary full model, SWDB row selection and weights not recovered |
| Cu, fcc | 2004 Table I and II | [Wang, Ahuja & Johansson (2002)](https://doi.org/10.1063/1.1518781) | Static table available; original numerical reduction and undamaged 2004 comparison coefficients remain needed |
| Pt, fcc | 2004 Table I and II | [Holmes et al. (1989)](https://doi.org/10.1063/1.344177), Figure 2 legend | Static table available; exact low-pressure Vinet reduction and fitting samples remain needed |
| Ta, bcc | 2004 Table I and II | Wang et al. (2002) | Static table available; reduction samples and original parameter-table typography remain unresolved |
| W, bcc | 2004 Table I and II | Hixson & Fritz (1992) | Static table available; original reduction tables and parameter-table typography remain unresolved |
| Au, fcc | **Dewaele & Loubeyre (2007), ref. 8**, with nonhydrostatic correction; 2008 Table VI comparison gives `V0=16.962`, `K0=167`, `K0'=5.88` | Wang et al. (2002) | Correct source and comparison coefficients identified; corrected observations and full correction not recovered |

Zn is explicitly excluded from the final average (2008 p. 6) because its shock
reduction is uncertain and the Hugoniot crosses melting near 80 GPa. Fe is not
one of the ten metals either. Its paired W observations are valuable evidence
for the Fe EOS but are not an additional ruby calibration standard here.

Kennedy and Keeler is the **American Institute of Physics Handbook, 3rd ed.
(1972), Chapter 4, pp. 4-38–4-105**, not a 1964 shock paper. The repository's
previously transcribed low-pressure Cu column of Table 4d-12 is not a substitute
for the unrecovered Co/Ni/Ag columns, nor proof of the exact rows used in 2008.
No generic Hugoniot coefficients or thermal parameters have been invented to
complete these branches.

### Directly recovered 2008 comparison coefficients

Both arms share the tabulated fixed `V0` and ultrasonic `K0`. Section IV says
the RSW and DAC fits use Vinet, fix `K0` to the ultrasonic value, and fit over
the pressure range of the current DAC measurements. `V0` is first determined
from the 0–5 GPa measurements, then fixed for the DAC fit. The actual regression
weights and low-pressure volume regression are not specified.

| Branch | `K0` fixed | DAC `K0'` | Reduced-shock `K0'` | Printed DAC / RSW 95% widths |
| --- | ---: | ---: | ---: | --- |
| Co | 184 | 4.73 | 4.93 | 0.06 / 0.04 |
| Co | 190 | 4.37 | 4.67 | 0.04 / 0.03 |
| Ni | 183 | 4.99 | 5.13 | 0.02 / 0.01 |
| Mo | 261 | 4.06 | 4.18 | 0.05 / 0.02 |
| Ag | 101 | 5.97 | 6.19 | 0.02 / 0.01 |

The nominal Mo and Ag pairs agree with their Figure 2 paths to respectively
0.0053 and 0.0099 GPa maximum. Nominal Ni differs by up to 0.285 GPa;
the Co branches differ by up to 0.523 GPa (`184`) or 0.138 GPa (`190`). All
five comparisons fall inside a box obtained from the printed derivative widths
plus the 0.03 GPa graph-reading allowance. This is **interval compatibility**,
not a confidence band: the coefficient covariance is unknown. It does not
identify the authors' precise Co branch, unrounded parameters or fit samples.
In particular, changing Ni's published `5.13` to `5.12` because it follows the
graph more closely would replace source evidence with a diagnostic choice.

### The 2004 chain and its access boundary

The publisher's indexed text recovers the 2004 discussion on p. 094112-3 and
Table II on p. 094112-5. The six RSW EOS were represented by Vinet fits over
**0–160 GPa**. The ruby modification held **A=1904 GPa fixed**, changed B from
7.665 to 9.5, and then produced revised DAC fits. This is an upstream
calibration step, not six independent validations of the 2008 output.

The indexed Table II has damaged digit ordering around bold fixed moduli and
adjacent derivatives (for example, the Pt RSW pair renders as `277.4, 6.6`).
Those exact extraction tokens are retained in the numerical report and are
**not silently decoded into an authoritative input table**. The publisher PDF
endpoint returned 401, the journal/link PDF endpoints returned 403, and an
ordinary browser visit displayed an institutional-login requirement. OpenAlex
listed no alternate PDF; DOI-specific HAL searches returned no records. These
access results do not establish that the primary data are absent. The existing
2004 audit records an earlier successfully inspected PDF checksum; that PDF
was not located in the scoped repository, downloads or temporary-source paths.

All 233 already bundled 2004 factual PV rows are retained in the new input
inventory. They are measured diffraction observations with *derived* pressure
coordinates. The 37 historical Au rows are explicitly marked as historical
comparison data, since 2008 cites the later corrected Au analysis. The
[2007 source](https://doi.org/10.1080/08957950701659627) was located, but its
full text could not be retrieved. The later [Takemura–Dewaele gold paper,
PRB 78, 104119](https://doi.org/10.1103/PhysRevB.78.104119) is a related study,
not ref. 8 of the calibration paper; its coefficients must not be substituted.

### Al: preliminary independent branch versus final joint model

Dorogokupets and Oganov's author-hosted full PDF was retrieved and visually
checked. Section II (pp. 3–4) describes two fitting stages. First, shock and
zero-pressure heat-capacity, expansion and elastic data constrain the model.
Second, static compression data with candidate pressure scales are included,
and the material parameters and ruby scale are revised together.

Section III, p. 024115-4, prints preliminary Al `K0=73.46, K0'=4.52`—exactly
the pair adopted in Dewaele (2008). Final Table I, p. 024115-6, instead prints
`72.67,4.62`. The final table cannot stand in for the initial Al input without
introducing the shared DAC/ruby fitting loop. The initial coefficients have no
explicit static-DAC dependency in the described first-stage objective; that
does not prove all their underlying experimental errors independent of the
other metals. The preliminary full thermal model, exact SWDB version and row
selection, fit weights and covariance remain missing. The fitted first-stage
modulus and derivative alone do not reproduce the entire shock reduction.

Wang's author thesis, Section 4.8, pp. 23–24, provides the underlying mean-field
reduction law: at a given pressure the calculated thermal **volume** increment
between the Hugoniot and 300 K isotherm is subtracted from the experimental
Hugoniot volume. This differs from merely subtracting a constant thermal
pressure. The thesis does not contain the full original numerical tables
needed to replay the Cu/Ta/Au input isotherms. The original 2002 paper's
abstract also identifies neglected shock melting and phase dependence as
assumptions; no model extension has been introduced here.

## Exact numerical coordinates and fitting order

Let `r=lambda/lambda0`. The input coordinate is

```text
P04 = (1904/9.5) [r^9.5 - 1]
ln(r) = ln(1 + 9.5 P04/1904) / 9.5
P08 = (1920/9.61) expm1[9.61 ln(r)]
```

For a printed Mao pressure, use `ln(r)=ln(1+7.665 PMao/1904)/7.665` instead.
Inverting the two independently rounded pressure columns need not give exactly
the same ratio. Absolute `lambda0` is unnecessary for this ratio calculation;
the original spectrometer wavelengths are not recovered by inversion.

At a chosen volume, Figure 2's coordinate is explicitly
`(P04(V), P_RSW(V)-P04(V))`. Thus a pressure-grid calculation must first invert
the **DAC** Vinet curve to obtain the volume and evaluate the RSW curve at
that same volume. It is not `P_RSW(P)-P04(P)`, not a volume residual, and not a
comparison of both EOS at the same nominal pressure. With common `V0,K0`,
the pressure ratio is

```text
P_RSW/P_DAC = exp[1.5 (K0'_RSW - K0'_DAC) (1-x)]
x = (V/V0)^(1/3)
```

This identity is useful for the coefficient-pair replay, but does not replace
the preceding shock reduction or recover missing source samples.

Figure 3 changes the horizontal coordinate to **Mao 1986 pressure** and plots
`Pnew-PMao`. Its caption describes a fit of the average of ten RSW pressures
to the ruby power law. This supports a pressure-average target and the stated
functional family. It does **not** specify equal pressure spacing, measured
point weighting, a common grid, a wavelength grid, pointwise renormalization
when a metal ends, extrapolation to 160 GPa, or a numerical residual norm.

The supported order is therefore: recover/reduce shock EOS; represent them
and DAC measurements by Vinet curves under their constraints; form pressures
at common volume and associated ruby coordinates; average over ten elements;
fit the ruby function. In 2008 A and B are both reported as optimized, unlike
2004's fixed A. The paper does not document bounds, parameter covariance,
whether any intermediate curves were iterated, or the exact optimizer.

### What the published curve actually checks

The Figure 3 orange curve is identified by its legend and PDF stroke color,
not by choosing a path that best matches the formula. Its 190 centerline
vertices span 0–182.541 GPa in Mao pressure. Tick positions, PDF curve identity,
mapping and original points are saved separately in `figure3-source.json`.
The printed formula differs by **0.0040 GPa RMS**, with maximum **0.0107 GPa**,
inside the declared 0.03 GPa centerline-reading bound. This establishes
source-equation agreement for the published output curve only.

At the wavelength corresponding to **P04=160 GPa**, the published calibration
gives **P08=161.94746 GPa**, a **1.94746 GPa** increase. The text's approximate
2.5 GPa statement is not this exact equation value. The earlier graph
continuation gives about 4.051 GPa, but continues several curves far beyond
their drawn domains and uses assumed compression shapes. Neither difference
identifies a typographical error or the missing averaging rule.

| Earlier explicitly conditional diagnostic | A, GPa | B | What remains assumed |
| --- | ---: | ---: | --- |
| Equal-metal mean, common 0–62.847 GPa support | 1909.48 | 10.2912 | Uniform pressure support and equal element weights |
| Pooled points on each curve's own domain | 1937.49 | 9.3448 | Equal total weight per metal and within-domain pressure grid |
| Equal-metal graph continuations to 160 GPa | 1915.67 | 10.0661 | Continuation shapes, extrapolation and equal pressure/metal weights |
| Published output, checked against Figure 3 | 1920 | 9.61 | Original optimization inputs and objective unrecovered |

The first three results are retained from the existing scoped audit; they are
not rerun with new arbitrary weights. Figure 2 does not show all ten elements
to 160 GPa: its shortest Co path ends at 62.847 GPa. Hence a ten-element mean
there necessarily requires an additional continuation or support decision.
The paper does not provide enough evidence to select one.

The drawn Figure 2 curves already extend beyond some selected DAC data:
Mo's selected rows end at 97.9 GPa while its recovered path reaches 118.35 GPa;
Ag ends at 97.9 GPa while its visible path reaches 103.71 GPa. The Al/Cu/W
tables reach 153 GPa and the plot reaches 160 GPa. Pt/Ta tables reach 93.6 GPa
and visible paths reach about 99.71/96.65 GPa. Thus the **figure** does use
fitted-curve continuation in places. This does not establish how the final
average handles such domains. A visible path ending at an axis boundary may
be clipped and is not a source statement of an EOS validity limit.

## Shared calibration and uncertainty

The new inventory preserves original pressure/volume tokens and row identities.
It gives two **derived log-wavelength coordinates** for ruby rows and no such
coordinate for He-derived rows. Neither column is called a measured wavelength.
Rows for co-compressed metals can share one ruby determination; counting each
material row as an independent ruby reading would duplicate that information.
The older CSVs do not retain full run identities, so no run assignment or exact
cross-run matching is invented from coincident rounded pressures.

For Ni run 6, the He EOS is identified in the Table II caption as
`V0=24.804 Å³/atom, K0=0.165 GPa, K0'=7.483`, from
[Loubeyre et al. (1998)](https://doi.org/10.1103/PhysRevB.57.10403).
The simultaneous He volumes are not printed. The resulting Ni curve must carry
that dependency into the average; those rows are not independent measured
ruby wavelengths or an independent calibration of the He scale.

For residual vector `d`, a defensible symbolic propagation is
`C_d = J_shared C_shared J_shared^T + C_other`, followed by
`Var(w^T d) = w^T C_d w`. Shared terms include input ruby parameters,
co-compressed ruby states, adopted elastic constraints, the He scale, and
common upstream reduction data/models. A shared `K0` appears once in both
arms and its derivative is taken through the difference. It must not be
propagated as two independent moduli. No numerical covariance, standard error
of the mean, effective number of independent standards, or new uncertainty on
A/B is claimed because the required covariance and weights are unavailable.

## Preserved pressure-pair inconsistency

The shared Ni/Zn run-6 state prints `49.0 → 51.0 GPa`. Literal Mao-to-2004
conversion gives **50.10367 GPa**; a 2004 pressure of 51 GPa would instead
correspond to about 49.86 GPa on the Mao scale. The original values survive.
The Ni volume at this state can be evaluated using the published Ni EOS, but
that EOS was fitted to these same data; it cannot independently decide which
printed coordinate is wrong. Zn remains excluded. No correction is applied
and no cause of the ten-metal-fit discrepancy is inferred from this pair.

## Evidence still required for a complete author replay

1. **Original numerical reduced isotherms:** Kennedy–Keeler Co/Ni/Ag columns
   and their reduction provenance; Hixson–Fritz Mo/W isotherm tables and
   thermodynamic inputs; the Wang Cu/Ta/Au reductions and Holmes Pt reduction
   actually fitted by Dewaele, including source row selection and weights.
2. **Undamaged 2004 Table II** and exact choices among its free- and fixed-K0
   DAC alternatives. Indexed text is useful for the method but insufficient
   for a definitive coefficient transcription.
3. **2007 corrected Au input:** diffraction rows or corrected volumes, the
   anisotropic-stress correction, pressure-scale version, and fit selection.
4. **Preliminary Al model:** full first-stage coefficients, SWDB version and
   measurement selection, fixed constraints and weights. Final Table I is a
   different stage and is not an independent substitute.
5. **Averaging/fitting specification:** actual common-volume or wavelength
   coordinates, included pressure intervals, point/grid construction, metal
   and point weights, handling outside each measured domain, residual norm,
   constraints and order. An original calculation sheet would resolve this
   more directly than further graph fits.
6. **Shared uncertainties:** original wavelength readings, simultaneous He
   volumes, run pairing and covariance. These are needed to substantiate the
   stated statistical improvement, beyond reproducing central coefficients.

These are evidence gaps and access limitations, not statements that the
measurements were never made or that the output calibration is disproven.
Author contact is a possible later step and has not been undertaken.

## Reproducible files and checks

Repository maintenance command, using an isolated environment:

```bash
uv run --no-project --with pdfplumber --with scipy --with matplotlib \
  python scripts/reconstruct_dewaele_2008_ruby_construction.py \
  --recover-pdf /path/to/PhysRevB.78.104102.pdf
```

Once the graph transcription exists, the reconstruction also runs with the
repository's NumPy/SciPy/Matplotlib environment and no PDF dependency:

```bash
python scripts/reconstruct_dewaele_2008_ruby_construction.py
```

Products are under `output/dewaele-2008-ruby-construction/`:

- `reconstruction.json`: coefficients, graph checks, preserved discrepancy,
  dependency qualifications and unresolved inputs.
- `source-table4-vinet-pairs.csv`: the five source coefficient pairs.
- `pressure-volume-input-inventory.csv`: original factual PV tokens and
  explicitly derived ruby coordinates, with historical Au and He flags.
- `figure3-source.json`: independently recovered output-curve checkpoints.
- `evidence-register.json`: source locations and access/recovery levels.
- `dependency-map.json`: directed calibration history and inherited shared
  ancestors, without invented numerical correlations.
- `calibration-comparison.png` and `.svg`: declared diagnostics versus the
  output formula, and the independent Figure 3 equation check.

The script never edits EOSMAT files, existing scripts, the previous metal audit
or common scientific ledgers. Downloaded articles and extracted source text
remain local investigation evidence; no third-party publication rights are
asserted. Numerical transcriptions retain source attribution. Passing the
checks establishes only the stated numerical and provenance properties,
not experimental validation or complete author-workflow reproduction.
